# GLFW binaries for macOS

This archive contains documentation, headers and pre-compiled static and dynamic
libraries for GLFW 3.4, targeting macOS 10.8 and later.  Both Intel
(x86\_64), Apple Silicon (arm64) and Universal binaries are provided.

